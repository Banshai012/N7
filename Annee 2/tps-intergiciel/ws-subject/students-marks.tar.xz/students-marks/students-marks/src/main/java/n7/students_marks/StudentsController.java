package n7.students_marks;

import java.util.Hashtable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentsController {

  /* bad, data should be stored in a database */
  static Hashtable<String, Student> students = new Hashtable<String, Student>();
  static Hashtable<String, Record> records = new Hashtable<String, Record>();

  static void addStudent(Student s) {
    students.put(s.getFirstname() + "-" + s.getLastname(), s);
  }

  static void addRecord(Record r) {
    records.put(r.getINE(), r);
  }

  @GetMapping("/getstudent")
  public Student getStudent(
      @RequestParam("firstname") String firstname, @RequestParam("lastname") String lastname) {
    String key = firstname + "-" + lastname;
    System.out.println("access student: " + key);
    return students.get(key);
  }

  @GetMapping("/getrecord")
  public Record getRecord(@RequestParam("ine") String ine) {
    System.out.println("access record: " + ine);
    return records.get(ine);
  }

  @GetMapping("/getmark")
  public int getMark(@RequestParam("firstname") String firstname, @RequestParam("lastname") String lastname, @RequestParam("lecture") String lecture) {
    Student student = students.get(firstname + "-" + lastname);
    String INE = student.getINE();
    Record record = records.get(INE);
    switch (lecture) {
      case "mathematics":
          return (Integer.parseInt(record.getMathematics()));

        case "middleware":
          return (Integer.parseInt(record.getMiddleware()));

        case "networks":
          return (Integer.parseInt(record.getNetworks()));

        case "systems":
          return (Integer.parseInt(record.getSystems()));

        case "architecture":
          return (Integer.parseInt(record.getArchitecture()));

        case "programming":
          return (Integer.parseInt(record.getProgramming()));

      default:
        return -1;
    }
  }

  /* This static initializer block only run once, when the class is loading
   * (before main is called) */
  static {
    addStudent(
        new Student(
            "1111111111",
            "Alain",
            "Tchana",
            "18/12/1984",
            "male",
            "3 rue Jeff Rouchon",
            "Toulouse",
            "31000",
            "France",
            "0102030405",
            "alain.tchana@enseeiht.fr"));
    addStudent(
        new Student(
            "2222222222",
            "Boris",
            "Teabe",
            "12/03/1990",
            "male",
            "6 rue Paul Biya",
            "Yaoundé",
            "xxxxx",
            "Cameroun",
            "0607080910",
            "boris.teabe@enseeiht.fr"));
    addStudent(
        new Student(
            "3333333333",
            "Axel",
            "Carlier",
            "05/07/1987",
            "male",
            "9 rue Denis Dartus",
            "Toulouse",
            "31000",
            "France",
            "0102030405",
            "axel.carlier@enseeiht.fr"));
    addStudent(
        new Student(
            "4444444444",
            "Zouheir",
            "Hamrouni",
            "07/10/1970",
            "male",
            "2 rue Geraldine Morin",
            "Toulouse",
            "31000",
            "France",
            "0102030405",
            "zouheir.hamrouni@enseeiht.fr"));
    addStudent(
        new Student(
            "5555555555",
            "Daniel",
            "Hagimont",
            "08/07/1965",
            "male",
            "1 Francois Asselineau",
            "Toulouse",
            "31000",
            "France",
            "0102030405",
            "daniel.hagimont@enseeiht.fr"));

    addRecord(new Record("1111111111", "12", "14", "11", "5", "16", "18"));
    addRecord(new Record("2222222222", "11", "7", "15", "16", "16", "2"));
    addRecord(new Record("3333333333", "9", "18", "11", "15", "16", "20"));
    addRecord(new Record("4444444444", "7", "19", "13", "5", "16", "18"));
    addRecord(new Record("5555555555", "9", "12", "11", "18", "3", "18"));
  }
}
